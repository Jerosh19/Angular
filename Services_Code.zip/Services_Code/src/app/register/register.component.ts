import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent  {

  constructor(private user:UserService){

  }

  form=new FormGroup({
    firstName: new FormControl('',[Validators.required,Validators.minLength(5),Validators.maxLength(10)]),
    lastName: new FormControl('',[Validators.required]),
    emailId: new FormControl('',[Validators.required]),
    password: new FormControl('',[Validators.required]),
    mobileNumber: new FormControl('',[Validators.required])
})

register(form){
   this.user.registerUser(form.value).subscribe(
     (response) => {
        console.log(JSON.stringify(response));
     }
   );
}

get firstName(){
 return this.form.get('firstName');
}
get lastName(){
  return this.form.get('lastName');
 }
 get emailId(){
  return this.form.get('emailId');
 }
 get password(){
  return this.form.get('password');
 }
 get mobileNumber(){
  return this.form.get('mobileNumber');
 }

}
